package com.demo;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.DHGenParameterSpec;
import java.security.*;

public class ErrorLocationDemo {

    public ErrorLocationDemo() throws InvalidAlgorithmParameterException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        demo(5, 10); // insecure parameters (line 25)
    }

    public void demo(int prime, int exp) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException {
        KeyPairGenerator kpGen = KeyPairGenerator.getInstance("DH");
        kpGen.initialize(2048); // insecure keysize (line 23)

        byte[] seed = "static seed".getBytes(); // insecure seed (line 27)
        KeyAgreement keyAgreement = KeyAgreement.getInstance("DH");
        keyAgreement.init(
                // this method call goes over multiple lines
                kpGen.generateKeyPair().getPrivate(),
                // we add comments to show that the location
                new DHGenParameterSpec(prime, exp),
                // reported by CogniCrypt is not very accurate
                new SecureRandom(seed)
        );
    }
}